import React from "react";
import Main from "./components/MainComponent";

export default class App extends React.Component {
  render() {
    return <Main />;
  }
}
